#coding=utf-8
class *(): 
    pass



if __name__ == '__main__':
    pass